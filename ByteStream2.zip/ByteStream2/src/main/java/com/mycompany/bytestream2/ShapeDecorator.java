/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bytestream2;

/**
 *
 * @author Student
 */
public abstract class ShapeDecorator {
    protected Shape shape;

    public ShapeDecorator(Shape shape) {
        this.shape = shape;
    }
    
    public void draw() {
        shape.draw();
    }
    
    
}
