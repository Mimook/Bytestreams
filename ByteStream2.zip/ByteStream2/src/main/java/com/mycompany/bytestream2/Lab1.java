/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bytestream2;

/**
 *
 * @author Student
 */
public class Lab1 {
    public static void main(String[] args) {
        Circle circle = new Circle();
        circle.draw();
        
        Rectangle rec = new Rectangle();
        rec.draw();
        
        RedShapeDecorator redcircle = new RedShapeDecorator(new Circle());
        RedShapeDecorator redrectangle = new RedShapeDecorator(new Rectangle());
        
        redcircle.draw();
        redrectangle.draw();
        
        
    }
}
